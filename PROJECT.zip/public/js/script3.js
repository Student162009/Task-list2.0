window.addEventListener('load', () => {
    const enter = document.querySelector("#enter");
    const Enter = document.getElementById("log-in");

enter.addEventListener("click", ()=>{
        Enter.play();
        setTimeout(() => {
            window.location.href = "/html/regist.html";
        }, 2000);
});
});