const DATAUSER = require("../data/data.js");
const addData = (req, res) => {
    const dataFromClient = req.body;
    const result = DATAUSER.addUserData(dataFromClient.Login, dataFromClient.Password, dataFromClient.Number, dataFromClient.firstname, dataFromClient.name, dataFromClient.email);

    if (!result) {
        res.status(409).send("УПС! ТАКОЙ ПОЛЬЗОВАТЕЛЬ УЖЕ ЕСТЬ");
        return;
    }

    res.status(200).json(result);
};

const Enter = (req, res) =>{
    const dataFromClient = req.body;
    const data = DATAUSER.GetUserData();

    const user = data.find(user => user.login === dataFromClient.Data && user.parol === dataFromClient.Password);
if(user){
    res.status(200).json({
        message: "Одобрено",
        firstname: user.firstname,
        name: user.name
    });
}else{
    res.status(409).send("УПС! ТАКОГО ЛОГИНА ИЛИ ПАРОЛЯ НЕТ");
}
};
const editPassword = (req, res) => {
    const { Login, Newpass} = req.body;
    const result = DATAUSER.editPassword(Login, Newpass);

    if (!result) {
        res.status(404).send("Логин не найден.");
        return;
    }

    res.status(200).json(result);
};

const editLogin = (req, res) => {
    const { Login, Newlogin} = req.body;
    const result = DATAUSER.editLogin(Login, Newlogin);

    if (!result) {
        res.status(404).send("Логин не найден.");
        return;
    }

    res.status(200).json(result);
};

const editFI = (req, res) => {
    const { Login, Newname, Newfirstname } = req.body;
    const result = DATAUSER.editFI(Login, Newname, Newfirstname);

    if (!result) {
        res.status(404).send("Пользователь не найден.");
        return;
    }

    res.status(200).json(result);
};

const deleteUser = (req, res) => {
    const { Login } = req.body;
    const result = DATAUSER.deleteUserData(Login);

    if (!result) {
        res.status(404).send("Пользователь не найден");
        return;
    }

    res.status(200).send("Пользователь удален");
};

const EnterEmail = (req, res) =>{
    const dataFromClient = req.body;
    const data = DATAUSER.GetUserData();

    const user = data.find(user => user.email === dataFromClient.Data && user.parol === dataFromClient.Password);
if(user){
    res.status(200).json({
        message: "Одобрено",
        firstname: user.firstname,
        name: user.name
    });
}else{
    res.status(409).send("УПС! ТАКОЙ ЭЛЕКТРОННОЙ ПОЧТЫ ИЛИ ПАРОЛЯ НЕТ");
}
};

const EnterTel = (req, res) =>{
    const dataFromClient = req.body;
    const data = DATAUSER.GetUserData();

    const user = data.find(user => user.numtel === dataFromClient.Data && user.parol === dataFromClient.Password);
if(user){
    res.status(200).json({
        message: "Одобрено",
        firstname: user.firstname,
        name: user.name
    });
}else{
    res.status(409).send("УПС! ТАКОГО ТЕЛЕФОНА ИЛИ ПАРОЛЯ НЕТ");
}
};

module.exports = {addData, Enter, editPassword, editLogin, editFI, deleteUser, EnterEmail, EnterTel};
